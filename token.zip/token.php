<?php 
include("config.php");
$Email = $_POST["Email"];
$token = $_POST["token"];


mysqli_query($con,"insert into chat (Email,token)values('$Email','$token',)")or die(mysqli_error($con));



?>