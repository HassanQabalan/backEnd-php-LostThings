<?php
echo "connection sucsses...."	;
$host = "localhost"
$db_user = "Mohammad"
$db_password = "pass"
$db_name = "firebase_db"

$con = mysql_connect = ($host,$db_user,$db_password,$db_name);
if ($con)
	echo "connection sucsses...."	;
else
	echo "Not sucsses......";
?>