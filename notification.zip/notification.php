<?php 
    require("config.php");
	function send_notification ($tokens, $message)
	{
		$url = 'https://fcm.googleapis.com/fcm/send';
		$fields = array(
			 'registration_ids' => $tokens,
			 'notification' => $message
			);
define( 'API_ACCESS_KEY','AAAA-WkBqUQ:APA91bFnkQLG_DC_U7MOK06DAHPYDwe6xWoZVQRl39vS8ELj7ZgRNcMZVdfznfhzxqnBuZtBkOoXbhezgKC-CHsvh3S5b-YwWY8T5PxrJ9GQrj3cDDA0M-PTQWXKZWhyZV-OW7U_u34p');

		$headers = array(
			'Authorization:key ='.API_ACCESS_KEY,
			'Content-Type: application/json'
			);

	   $ch = curl_init();
       curl_setopt($ch, CURLOPT_URL, $url);
       curl_setopt($ch, CURLOPT_POST, true);
       curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
       curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);  
       curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
       curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
       $result = curl_exec($ch);           
       if ($result === FALSE) {
           die('Curl failed: ' . curl_error($ch));
       }
       curl_close($ch);
       return $result;
	}
	$result = mysqli_query($con,"SELECT  token FROM ---- ");
    $tokens = array();
    if(mysqli_num_rows($result) > 0 ){
	while ($row = mysqli_fetch_assoc($result)) {
			$tokens[] = $row["token"];
		}
		mysqli_close($con);
	}
	
	 
	$message_status = send_notification($tokens, $message);
  	$message = array
            (
  		'body' 	=> 'test', 
  		'title'	=> 'test');
  	$message_status = send_notification($tokens, $message);	


 ?>

