<?php 
include("config.php");

$name = $_POST["name"];
$id = $_POST["id"];
$text = $_POST["text"];

mysqli_query($con,"insert into post(name , id , text )values('$name','$id' , '$text')")or die(mysqli_error($con));

$stmt = $con->prepare("SELECT name, id,text FROM post ");
	$stmt->execute();
	$stmt->bind_result($name,$id, $text);
	$contact = array(); 
	while($stmt->fetch()){
		$temp = array();
		$temp['name'] = $name; 
		$temp['id'] = $id; 
		$temp['text'] = $text; 
		
		array_push($contact, $temp);
	}
	echo json_encode($contact);
	
	
?>