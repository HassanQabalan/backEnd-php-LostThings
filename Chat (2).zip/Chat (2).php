<?php 
include("config.php");
$Email = $_POST["Password"];
$Password = $_POST["Password"];

 
if ($name != null){
mysqli_query($con,"insert into login (email,password)values('$Email','$Password')")or die(mysqli_error($con));
}
	

	?>