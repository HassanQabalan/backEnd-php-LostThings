<?php 
include("config.php");

 $image = $_POST["image"];
 $name = $_POST["name"];
 
  $uploadpath = "image/$name.jpg";
  
  file_put_contents($uploadpath,base64_decode($image));
  
    $insert= mysqli_query($con,"insert into imge (image) values ('$nuploadpathame)") or die(mysqli_error($con));


?>