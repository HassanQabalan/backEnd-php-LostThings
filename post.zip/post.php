<?php 
include("config.php");

$name = $_POST["name"];
$id = $_POST["id"];
$text = $_POST["text"];

mysqli_query($con,"insert into post(name , id , text)values('$name','$id' , '$text')")or die(mysqli_error($con));



?>